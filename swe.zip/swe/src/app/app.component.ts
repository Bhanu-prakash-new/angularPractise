import { Component } from '@angular/core';

interface objInterface {
  a: number;
  b: number;
  
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  inputObj = {} as objInterface; // prepares the object by looking into inteface.
  result: number = 0;
  selectedOperator: string = '+';
  
  constructor() { // It will initializes the varaibles and the methodss

  }
 // this means . it is used for accessing the properties and methods declared in the class component
  handleMathOperation(typeOfCalculation: string) {
    let {a,b} = this.inputObj;//Destructring the object
    
    switch (typeOfCalculation) {
      case "add":
        this.result = a + b;
        this.selectedOperator = '+';
        break;
      case "div":
        this.result = a / b;
        this.selectedOperator = '/';
        break;
      case "mul":
        this.result = a * b;
        this.selectedOperator = '*';
        break;
      case "sub":
        this.result = a - b;
        this.selectedOperator = '-';
        break;

    }
  }

  reset(){
    this.inputObj = {a:0,b:0};
  }
  
}
